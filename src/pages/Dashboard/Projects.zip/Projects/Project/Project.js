import React, { useEffect, useState } from "react";
import styles from "./Project.module.css";
import plusIcon from "../../../../images/plusIcon.png";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Button } from "@mui/material";
// import { ProgressBarLine } from "react-progressbar-line";
import axios from "axios";
import threeDots from "../../../../images/threeDots.png";
import { useInvoiceContext } from "../../../../hooks/useInvoiceContext";
import SettingsIcon from "@mui/icons-material/Settings";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFetch } from "../../../../hooks/useFetch";

const Project = () => {
  const { id } = useParams();

  const projectUrl = `http://localhost:5000/api/v1/jobs/client/${id}`;
  // const [clientId,setClientID]=useState("")
  // const navigate = useNavigate();
  // const [error, setError] = useState(null);
  // const [isLoading, setIsLoading] = useState(false);
  const [url, setUrl] = useState(`http://localhost:5000/api/v1/Jobs`);
  const { data: deletedData } = useFetch(url, "DELETE");

  const { data: allProjects, isLoading, error } = useFetch(projectUrl, "GET");
  // const [allJobs, setAllJobs] = useState([]);
  // const [searchparams] = useSearchParams();
  const [activeBtn1, setActiveBtn1] = useState(true);
  const [activeBtn2, setActiveBtn2] = useState(false);
  const [activeBtn3, setActiveBtn3] = useState(false);
  const { dispatch, allJobs } = useInvoiceContext();
  const navigate = useNavigate();
  // const [jobType, setJobType] = useState("");
  // console.log("JobsPage__clientID>>>", searchparams.get("new_ID"));
  console.log("All_Projects_from_custom_fetch_hook>>>", allProjects);

  useEffect(() => {
    dispatch({
      type: "GET_ALL_JOBS",
      payload: allProjects?.data,
    });
  }, [dispatch, allProjects]);
  // let clientId = searchparams.get("new_ID");
  // console.log("ClientId>>>>", id);

  // const getData = useCallback(async () => {
  //   setIsLoading(true);
  //   setError(null);

  //   try {
  //     const { data } = await axios.get(
  //       `http://localhost:5000/api/v1/jobs/client/${id}`
  //     );

  //     if (data) {
  //       setIsLoading(false);
  //       setError(null);
  //       console.log("all jobs==>", data.data);
  //       // setAllJobs(data.data);
  //       dispatch({
  //         type: "GET_ALL_JOBS",
  //         payload: data.data,
  //       });
  //     }
  //   } catch (error) {
  //     setIsLoading(false);
  //     setError(error.response.data);
  //     console.log("all jobs error==>", error);
  //   }
  // }, [dispatch, id]);

  // useEffect(() => {
  //   getData();
  // }, [getData]);

  const handleShowPopup = (id) => {
    // console.log("_id>>>>>>", id);
    const newJobs = allJobs.map((job) => {
      if (job._id === id) {
        // console.log("ID==>", id);
        return { ...job, isSelected: !job.isSelected };
      } else {
        return job;
      }
    });
    // dispatch({
    //   type: "GET_ALL_CLIENTS",
    //   payload: newClients,
    // });
    // console.log("new jobs==>", newJobs);
    dispatch({
      type: "GET_ALL_JOBS",
      payload: newJobs,
    });
  };

  const handleDelete = async (id) => {
    console.log("Jobs__Deleted__id>>>>", id);
    setUrl(`http://localhost:5000/api/v1/jobs/${id}`);
    if (deletedData) {
      dispatch({
        type: "DELETE__JOBS",
        payload: id,
      });
      console.log("Job_Deleted_Data>>>", deletedData);
      showToastMessage("Job Deleted Sucessfully.");
    }

    // try {
    //   const { data } = await axios.delete(
    //     `http://localhost:5000/api/v1/jobs/${id}`
    //   );

    //   if (data) {
    //     console.log("Deleted_Jobs>>>", data);
    //     dispatch({
    //       type: "DELETE__JOBS",
    //       payload: data.data,
    //     });
    //     showToastMessage(data.message);
    //   }
    // } catch (error) {
    //   console.log(error);
    // }
  };

  // FUNCTION FOR TOAST MESSAGE
  const showToastMessage = (message) => {
    toast.success(message, {
      position: toast.POSITION.TOP_RIGHT,
    });
  };

  const fetchTypeViceJobs = async (url) => {
    const data = await fetchQueryJobs(url);
    console.log("Query__data>>>", data);
    dispatch({
      type: "GET_ALL_JOBS",
      payload: data?.data,
    });

    let newUrl = url.split("=")[1];
    if (newUrl == "incomplete") {
      setActiveBtn1(false);
      setActiveBtn2(true);
      setActiveBtn3(false);
    }
    if (newUrl == "complete") {
      setActiveBtn1(false);
      setActiveBtn2(false);
      setActiveBtn3(true);
    }
  };

  const fetchAllJobs = () => {
    setActiveBtn1(true);
    setActiveBtn2(false);
    setActiveBtn3(false);
    dispatch({
      type: "GET_ALL_JOBS",
      payload: allProjects?.data,
    });
  };

  const fetchQueryJobs = async (url) => {
    try {
      const { data } = await axios.get(url);
      if (data) {
        // console.log("Query__Jobs>>>", data);
        return data;
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleCompleteJob = async (id) => {
    console.log("Id>>>>", id);
    try {
      const { data } = await axios.patch(
        `http://localhost:5000/api/v1/Jobs/${id}`
      );
      if (data) {
        console.log(data?.message + ">>>>", data);
        // dispatch({
        //   type: "CREATE__JOBS",
        //   payload: data?.data,
        // });
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className={styles.container}>
      <h1>Project</h1>
      <div className={styles.top}>
        <div className={styles.topLeft}>
          <button
            onClick={fetchAllJobs}
            style={{
              backgroundColor: activeBtn1 && "#52b94c",
              color: activeBtn1 && "#ffffff",
            }}
          >
            All
          </button>
          <button
            onClick={() =>
              fetchTypeViceJobs(
                `http://localhost:5000/api/v1/Jobs?isCompleted=incomplete`
              )
            }
            style={{
              backgroundColor: activeBtn2 && "#52b94c",
              color: activeBtn2 && "#ffffff",
            }}
          >
            Ongoing
          </button>
          <button
            onClick={() =>
              fetchTypeViceJobs(
                `http://localhost:5000/api/v1/Jobs?isCompleted=complete`
              )
            }
            style={{
              backgroundColor: activeBtn3 && "#52b94c",
              color: activeBtn3 && "#ffffff",
            }}
          >
            Finished
          </button>
        </div>

        <div className={styles.topRight}>
          <select name="" id="">
            <option value="Today">Today</option>
          </select>
          <select name="" id="">
            <option value="Filter">Filter</option>
          </select>
          <Link to={`/dashboard/projects/create/${id}`} className={styles.btn}>
            <img src={plusIcon} alt="" />
            <span>Create</span>
          </Link>
        </div>
      </div>

      {/********* Tables *************/}

      <div className={styles.project_dashboard_table}>
        {isLoading && <h1 className={styles.isLoading}>Loading...</h1>}
        {error && <div className={styles.error}>{error}</div>}
        {!error && !isLoading && (
          <table>
            <thead>
              <tr className={styles.table__header}>
                <th>Project Name</th>
                <th>Project Budget</th>
                <th>Job Location</th>
                <th>Project Team</th>
                <th>Progress</th>
                <th>Job Status</th>
                <th>
                  <SettingsIcon style={{ color: "#ffffff", height: "20px" }} />
                </th>
              </tr>
            </thead>
            <tbody className={styles.gfg}>
              {allJobs?.map((jobs, id) => (
                <tr key={jobs._id} className={styles.table__row}>
                  {/* MODAL_FOR_JOB_COMPLETETION */}
                  {/* {showModal && (
                    <div className={styles.modal__container}>
                      <div className={styles.modal__inner}>
                        <h2>Want to finish this job?</h2>
                        <button>Press to complete</button>
                        <button>Cancel</button>
                      </div>
                    </div>
                  )} */}

                  <td>{jobs?.projectName}</td>
                  <td style={{ color: "#6BDB65" }}>${jobs?.projectBudget}</td>
                  <td>{jobs?.jobLocation}</td>
                  <td style={{ color: "rgba(255, 255, 255, 0.55)" }}>
                    {jobs?.projectTeamAndResourceRequirement}
                  </td>
                  {/* <td>{jobs?.startDate.split("T")[0]}</td> */}
                  <td style={{ textTransform: "capitalize" }}>
                    {/* <ProgressBarLine
                      value={75}
                      min={0}
                      max={100}
                      strokeWidth={5}
                      trailWidth={5}
                      styles={{
                        path: {
                          stroke: "#6BDB65",
                        },
                        trail: {
                          stroke: "#a6e2a3",
                        },
                        text: {
                          fill: "#6BDB65",
                          textAlign: "center",
                          fontSize: "10px",
                          display: "none",
                        },
                      }}
                    /> */}
                    {jobs?.isCompleted == "complete"
                      ? "Completed"
                      : "Incomplete"}
                  </td>
                  {jobs?.isCompleted == "incomplete" ? (
                    <td className={styles.select_btn}>
                      <Button onClick={() => handleCompleteJob(jobs?._id)}>
                        Complete Job
                      </Button>
                    </td>
                  ) : (
                    <td className={styles.select_btn}>
                      <Button disabled style={{ opacity: "0.5" }}>
                        Complete Job
                      </Button>
                    </td>
                  )}
                  <td>
                    <img
                      src={threeDots}
                      alt=""
                      style={{ cursor: "pointer", height: "28px" }}
                      onClick={() => handleShowPopup(jobs?._id)}
                    />

                    {jobs.isSelected && (
                      <div className={styles.popup}>
                        <div
                          onClick={() =>
                            navigate(`/dashboard/invoices/${jobs._id}`)
                          }
                        >
                          Invoice
                        </div>
                        <div onClick={() => handleDelete(jobs._id)}>Delete</div>
                        <div>
                          <Link
                            to="/dashboard/updateClients"
                            style={{ textDecoration: "none" }}
                            state={{ job: jobs }}
                          >
                            Update
                          </Link>
                        </div>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* <div className={styles.tableContainer}>
        <ul className={styles.tableHeader}>
          <div className={styles.firstList}>
            <li>
              <span>Project Name</span>
            </li>
          </div>

          <div className={styles.remainingList}>
            <li>
              <span>Project Budget</span>
            </li>
            <li>
              <span>Type</span>
            </li>
            <li>
              <span>Start Date</span>
            </li>
            <li>
              <span>End Date</span>
            </li>
            <li>
              <span>Task Progress</span>
            </li>
          </div>
        </ul>

        <ul className={styles.tableList}>
          <div className={styles.firstList}>
            <li>
              <span>Turbo - App Design</span>
            </li>
          </div>

          <div className={styles.remainingList}>
            <li>
              <span>$0.00</span>
            </li>
            <li>
              <span>Audio</span>
            </li>
            <li>
              <span>20/4/2022</span>
            </li>
            <li>
              <span>20/6/2022</span>
            </li>
            <li>
              <span>Task Progress</span>
            </li>
          </div>
        </ul>
      </div> */}
      <ToastContainer />
    </div>
  );
};

export default Project;
